// lib/main.dart
// Entry point. Initialises notifications and timezone data before runApp.

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'app.dart';
import 'services/notification_service.dart';
import 'services/storage_service.dart';
import 'core/constants.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Lock to portrait
  await SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
    DeviceOrientation.portraitDown,
  ]);

  // Translucent status bar
  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: Colors.transparent,
    statusBarIconBrightness: Brightness.light,
    systemNavigationBarColor: Color(0xFF18181C),
    systemNavigationBarIconBrightness: Brightness.light,
  ));

  // Initialise local notifications
  final notifications = NotificationService();
  await notifications.init();

  // Schedule default reminder if not already set
  final storage = StorageService();
  final hour = await storage.getReminderHour();
  final minute = await storage.getReminderMinute();
  await notifications.scheduleDailyReminder(hour: hour, minute: minute);

  runApp(const FounderScoreApp());
}
