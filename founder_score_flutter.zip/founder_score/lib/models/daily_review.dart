// lib/models/daily_review.dart
// Represents one day's full review entry.

class DailyReview {
  final String id;          // ISO date string: "2024-01-15"
  final DateTime date;

  // Category scores (0-10 each)
  final Map<String, double> scores;

  // Reflection text fields
  final String biggestWin;
  final String biggestMistake;
  final String whatIBuilt;
  final String tomorrowPriority;

  // Computed
  int get totalScore => scores.values.fold(0, (sum, v) => sum + v.round());

  DailyReview({
    required this.id,
    required this.date,
    required this.scores,
    this.biggestWin = '',
    this.biggestMistake = '',
    this.whatIBuilt = '',
    this.tomorrowPriority = '',
  });

  // ── Serialisation ─────────────────────────────────────────────────────────

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'date': date.toIso8601String(),
      'scores': scores.entries.map((e) => '${e.key}:${e.value}').join(','),
      'biggest_win': biggestWin,
      'biggest_mistake': biggestMistake,
      'what_i_built': whatIBuilt,
      'tomorrow_priority': tomorrowPriority,
    };
  }

  factory DailyReview.fromMap(Map<String, dynamic> map) {
    // Parse "key:value,key:value" score string
    final scoresMap = <String, double>{};
    if (map['scores'] != null && (map['scores'] as String).isNotEmpty) {
      for (final part in (map['scores'] as String).split(',')) {
        final kv = part.split(':');
        if (kv.length == 2) {
          scoresMap[kv[0]] = double.tryParse(kv[1]) ?? 0;
        }
      }
    }
    return DailyReview(
      id: map['id'] as String,
      date: DateTime.parse(map['date'] as String),
      scores: scoresMap,
      biggestWin: map['biggest_win'] as String? ?? '',
      biggestMistake: map['biggest_mistake'] as String? ?? '',
      whatIBuilt: map['what_i_built'] as String? ?? '',
      tomorrowPriority: map['tomorrow_priority'] as String? ?? '',
    );
  }

  DailyReview copyWith({
    Map<String, double>? scores,
    String? biggestWin,
    String? biggestMistake,
    String? whatIBuilt,
    String? tomorrowPriority,
  }) {
    return DailyReview(
      id: id,
      date: date,
      scores: scores ?? this.scores,
      biggestWin: biggestWin ?? this.biggestWin,
      biggestMistake: biggestMistake ?? this.biggestMistake,
      whatIBuilt: whatIBuilt ?? this.whatIBuilt,
      tomorrowPriority: tomorrowPriority ?? this.tomorrowPriority,
    );
  }
}
