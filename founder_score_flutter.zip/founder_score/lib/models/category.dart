// lib/models/category.dart
// Represents a scoring category (can be custom-edited in Settings).

class ScoringCategory {
  final String id;
  final String label;
  final String emoji;

  const ScoringCategory({
    required this.id,
    required this.label,
    required this.emoji,
  });

  Map<String, dynamic> toMap() => {'id': id, 'label': label, 'emoji': emoji};

  factory ScoringCategory.fromMap(Map<String, dynamic> map) => ScoringCategory(
        id: map['id'] as String,
        label: map['label'] as String,
        emoji: map['emoji'] as String? ?? '📊',
      );

  ScoringCategory copyWith({String? label, String? emoji}) => ScoringCategory(
        id: id,
        label: label ?? this.label,
        emoji: emoji ?? this.emoji,
      );
}
