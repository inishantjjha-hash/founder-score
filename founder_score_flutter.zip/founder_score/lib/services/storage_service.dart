// lib/services/storage_service.dart
// Handles all local persistence via SQLite (reviews) + SharedPreferences (settings).

import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart' as p;
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';

import '../core/constants.dart';
import '../models/daily_review.dart';
import '../models/category.dart';

class StorageService {
  static final StorageService _instance = StorageService._internal();
  factory StorageService() => _instance;
  StorageService._internal();

  Database? _db;

  // ── Init ──────────────────────────────────────────────────────────────────

  Future<Database> get database async {
    _db ??= await _initDb();
    return _db!;
  }

  Future<Database> _initDb() async {
    final dbPath = await getDatabasesPath();
    final path = p.join(dbPath, AppConstants.dbName);

    return openDatabase(
      path,
      version: AppConstants.dbVersion,
      onCreate: (db, version) async {
        await db.execute('''
          CREATE TABLE ${AppConstants.reviewsTable} (
            id TEXT PRIMARY KEY,
            date TEXT NOT NULL,
            scores TEXT NOT NULL,
            biggest_win TEXT,
            biggest_mistake TEXT,
            what_i_built TEXT,
            tomorrow_priority TEXT
          )
        ''');
      },
    );
  }

  // ── Reviews CRUD ──────────────────────────────────────────────────────────

  /// Insert or replace a review for a given day.
  Future<void> saveReview(DailyReview review) async {
    final db = await database;
    await db.insert(
      AppConstants.reviewsTable,
      review.toMap(),
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  /// Fetch a single review by date string (e.g. "2024-01-15").
  Future<DailyReview?> getReviewById(String id) async {
    final db = await database;
    final maps = await db.query(
      AppConstants.reviewsTable,
      where: 'id = ?',
      whereArgs: [id],
    );
    if (maps.isEmpty) return null;
    return DailyReview.fromMap(maps.first);
  }

  /// Fetch all reviews, ordered newest-first.
  Future<List<DailyReview>> getAllReviews() async {
    final db = await database;
    final maps = await db.query(
      AppConstants.reviewsTable,
      orderBy: 'date DESC',
    );
    return maps.map(DailyReview.fromMap).toList();
  }

  /// Get reviews for the last N days.
  Future<List<DailyReview>> getRecentReviews(int days) async {
    final cutoff = DateTime.now().subtract(Duration(days: days));
    final db = await database;
    final maps = await db.query(
      AppConstants.reviewsTable,
      where: 'date >= ?',
      whereArgs: [cutoff.toIso8601String()],
      orderBy: 'date ASC',
    );
    return maps.map(DailyReview.fromMap).toList();
  }

  Future<void> deleteReview(String id) async {
    final db = await database;
    await db.delete(
      AppConstants.reviewsTable,
      where: 'id = ?',
      whereArgs: [id],
    );
  }

  // ── Settings (SharedPreferences) ──────────────────────────────────────────

  Future<SharedPreferences> get _prefs => SharedPreferences.getInstance();

  Future<int> getReminderHour() async {
    final p = await _prefs;
    return p.getInt(AppConstants.prefReminderHour) ??
        AppConstants.defaultReminderHour;
  }

  Future<int> getReminderMinute() async {
    final p = await _prefs;
    return p.getInt(AppConstants.prefReminderMinute) ??
        AppConstants.defaultReminderMinute;
  }

  Future<void> setReminderTime(int hour, int minute) async {
    final p = await _prefs;
    await p.setInt(AppConstants.prefReminderHour, hour);
    await p.setInt(AppConstants.prefReminderMinute, minute);
  }

  /// Returns categories as JSON string list.
  Future<List<ScoringCategory>> getCategories() async {
    final p = await _prefs;
    final raw = p.getString(AppConstants.prefCategories);
    if (raw == null) {
      // Return defaults
      return kDefaultCategories.map(ScoringCategory.fromMap).toList();
    }
    final list = jsonDecode(raw) as List;
    return list.map((e) => ScoringCategory.fromMap(e as Map<String, dynamic>)).toList();
  }

  Future<void> saveCategories(List<ScoringCategory> cats) async {
    final p = await _prefs;
    await p.setString(
      AppConstants.prefCategories,
      jsonEncode(cats.map((c) => c.toMap()).toList()),
    );
  }
}
