// lib/services/export_service.dart
// Generates a CSV from all stored reviews and triggers share sheet.

import 'dart:io';
import 'package:csv/csv.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import 'package:intl/intl.dart';

import '../models/daily_review.dart';
import '../models/category.dart';
import 'storage_service.dart';

class ExportService {
  final StorageService _storage = StorageService();

  Future<void> exportToCsv() async {
    final reviews = await _storage.getAllReviews();
    final categories = await _storage.getCategories();

    if (reviews.isEmpty) return;

    // Build header row
    final headers = <String>[
      'Date',
      ...categories.map((c) => c.label),
      'Total Score',
      'Biggest Win',
      'Biggest Mistake',
      'What I Built',
      "Tomorrow's Priority",
    ];

    // Build data rows
    final rows = <List<dynamic>>[headers];
    for (final review in reviews) {
      rows.add([
        DateFormat('yyyy-MM-dd').format(review.date),
        ...categories.map((c) => review.scores[c.id]?.round() ?? 0),
        review.totalScore,
        review.biggestWin,
        review.biggestMistake,
        review.whatIBuilt,
        review.tomorrowPriority,
      ]);
    }

    // Convert to CSV string
    final csvString = const ListToCsvConverter().convert(rows);

    // Write to temp file
    final dir = await getTemporaryDirectory();
    final fileName =
        'founder_score_${DateFormat('yyyyMMdd_HHmm').format(DateTime.now())}.csv';
    final file = File('${dir.path}/$fileName');
    await file.writeAsString(csvString);

    // Share / save
    await Share.shareXFiles(
      [XFile(file.path)],
      subject: 'Founder Score Export',
    );
  }
}
