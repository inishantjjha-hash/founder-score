// lib/core/constants.dart

class AppConstants {
  // Notification
  static const int notificationId = 42;
  static const String notificationChannelId = 'founder_review';
  static const String notificationChannelName = 'Daily Founder Review';
  static const String notificationTitle = 'Founder Review';
  static const String notificationBody = 'What did you build today?';

  // Default reminder time
  static const int defaultReminderHour = 22;   // 10 PM
  static const int defaultReminderMinute = 0;

  // Score
  static const int maxScore = 60; // 6 categories × 10
  static const int categoriesCount = 6;

  // DB
  static const String dbName = 'founder_score.db';
  static const int dbVersion = 1;
  static const String reviewsTable = 'daily_reviews';

  // SharedPreferences keys
  static const String prefReminderHour   = 'reminder_hour';
  static const String prefReminderMinute = 'reminder_minute';
  static const String prefCategories     = 'custom_categories';
  static const String prefOnboarded      = 'onboarded';
}

// Default scoring categories — order matters for CSV export
const List<Map<String, dynamic>> kDefaultCategories = [
  {'id': 'study',          'label': 'Study',          'emoji': '📚'},
  {'id': 'business',       'label': 'Business',       'emoji': '💼'},
  {'id': 'ai_skill',       'label': 'AI Skill',       'emoji': '🤖'},
  {'id': 'client_outreach','label': 'Client Outreach','emoji': '📡'},
  {'id': 'health',         'label': 'Health / Fitness','emoji': '💪'},
  {'id': 'sleep',          'label': 'Sleep',          'emoji': '🌙'},
];
