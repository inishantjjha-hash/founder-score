// lib/core/theme.dart
// Design system: deep charcoal base, amber accent, IBM Plex for data feel

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class AppTheme {
  // ── Palette ──────────────────────────────────────────────────────────────
  static const Color background   = Color(0xFF0D0D0F);  // near-black
  static const Color surface      = Color(0xFF18181C);  // card bg
  static const Color surfaceHigh  = Color(0xFF222228);  // elevated card
  static const Color accent       = Color(0xFFFFB547);  // amber / gold
  static const Color accentDim    = Color(0x33FFB547);  // accent 20%
  static const Color textPrimary  = Color(0xFFF2F2F5);
  static const Color textSecondary= Color(0xFF8C8C99);
  static const Color divider      = Color(0xFF2A2A33);
  static const Color success      = Color(0xFF4ADE80);
  static const Color warning      = Color(0xFFFBBF24);
  static const Color error        = Color(0xFFF87171);

  // Score tier colors
  static const Color scoreExcellent = Color(0xFF4ADE80);
  static const Color scoreGood      = Color(0xFFFFB547);
  static const Color scoreAverage   = Color(0xFFFB923C);
  static const Color scoreWeak      = Color(0xFFF87171);

  // ── Typography ───────────────────────────────────────────────────────────
  // Display: Space Grotesk (geometric, founder-energy)
  // Body:    IBM Plex Sans (data-forward, legible at small sizes)
  static TextTheme get textTheme => TextTheme(
    displayLarge: GoogleFonts.spaceGrotesk(
      fontSize: 48, fontWeight: FontWeight.w700,
      color: textPrimary, letterSpacing: -2,
    ),
    displayMedium: GoogleFonts.spaceGrotesk(
      fontSize: 36, fontWeight: FontWeight.w700,
      color: textPrimary, letterSpacing: -1.5,
    ),
    headlineLarge: GoogleFonts.spaceGrotesk(
      fontSize: 28, fontWeight: FontWeight.w600,
      color: textPrimary, letterSpacing: -0.5,
    ),
    headlineMedium: GoogleFonts.spaceGrotesk(
      fontSize: 22, fontWeight: FontWeight.w600,
      color: textPrimary,
    ),
    titleLarge: GoogleFonts.ibmPlexSans(
      fontSize: 18, fontWeight: FontWeight.w600,
      color: textPrimary,
    ),
    titleMedium: GoogleFonts.ibmPlexSans(
      fontSize: 16, fontWeight: FontWeight.w500,
      color: textPrimary,
    ),
    bodyLarge: GoogleFonts.ibmPlexSans(
      fontSize: 16, fontWeight: FontWeight.w400,
      color: textPrimary,
    ),
    bodyMedium: GoogleFonts.ibmPlexSans(
      fontSize: 14, fontWeight: FontWeight.w400,
      color: textSecondary,
    ),
    labelLarge: GoogleFonts.ibmPlexSans(
      fontSize: 14, fontWeight: FontWeight.w600,
      color: textPrimary, letterSpacing: 0.5,
    ),
    labelSmall: GoogleFonts.ibmPlexMono(
      fontSize: 11, fontWeight: FontWeight.w500,
      color: textSecondary, letterSpacing: 0.8,
    ),
  );

  // ── ThemeData ─────────────────────────────────────────────────────────────
  static ThemeData get dark => ThemeData(
    useMaterial3: true,
    brightness: Brightness.dark,
    scaffoldBackgroundColor: background,
    colorScheme: const ColorScheme.dark(
      background: background,
      surface: surface,
      primary: accent,
      secondary: accent,
      error: error,
      onBackground: textPrimary,
      onSurface: textPrimary,
      onPrimary: background,
    ),
    textTheme: textTheme,
    appBarTheme: AppBarTheme(
      backgroundColor: background,
      elevation: 0,
      scrolledUnderElevation: 0,
      centerTitle: false,
      titleTextStyle: GoogleFonts.spaceGrotesk(
        fontSize: 20, fontWeight: FontWeight.w700,
        color: textPrimary, letterSpacing: -0.5,
      ),
      iconTheme: const IconThemeData(color: textPrimary),
    ),
    cardTheme: CardTheme(
      color: surface,
      elevation: 0,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
        side: const BorderSide(color: divider, width: 1),
      ),
      margin: EdgeInsets.zero,
    ),
    sliderTheme: SliderThemeData(
      activeTrackColor: accent,
      inactiveTrackColor: divider,
      thumbColor: accent,
      overlayColor: accentDim,
      valueIndicatorColor: accent,
      valueIndicatorTextStyle: GoogleFonts.ibmPlexMono(
        color: background, fontWeight: FontWeight.w700, fontSize: 14,
      ),
      trackHeight: 4,
      thumbShape: const RoundSliderThumbShape(enabledThumbRadius: 10),
      showValueIndicator: ShowValueIndicator.always,
    ),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: surfaceHigh,
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: const BorderSide(color: divider),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: const BorderSide(color: divider),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: const BorderSide(color: accent, width: 1.5),
      ),
      hintStyle: GoogleFonts.ibmPlexSans(color: textSecondary, fontSize: 14),
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
    ),
    dividerTheme: const DividerThemeData(color: divider, thickness: 1),
    navigationBarTheme: NavigationBarThemeData(
      backgroundColor: surface,
      indicatorColor: accentDim,
      labelTextStyle: WidgetStateProperty.all(
        GoogleFonts.ibmPlexSans(fontSize: 12, fontWeight: FontWeight.w500),
      ),
      iconTheme: WidgetStateProperty.resolveWith((states) {
        if (states.contains(WidgetState.selected)) {
          return const IconThemeData(color: accent);
        }
        return const IconThemeData(color: textSecondary);
      }),
    ),
    elevatedButtonTheme: ElevatedButtonThemeData(
      style: ElevatedButton.styleFrom(
        backgroundColor: accent,
        foregroundColor: background,
        elevation: 0,
        padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        textStyle: GoogleFonts.spaceGrotesk(
          fontSize: 16, fontWeight: FontWeight.w700, letterSpacing: 0.2,
        ),
      ),
    ),
    textButtonTheme: TextButtonThemeData(
      style: TextButton.styleFrom(
        foregroundColor: accent,
        textStyle: GoogleFonts.ibmPlexSans(
          fontSize: 14, fontWeight: FontWeight.w600,
        ),
      ),
    ),
  );

  // ── Helpers ───────────────────────────────────────────────────────────────
  static Color scoreColor(int score) {
    if (score >= 55) return scoreExcellent;
    if (score >= 45) return scoreGood;
    if (score >= 35) return scoreAverage;
    return scoreWeak;
  }

  static String scoreLabel(int score) {
    if (score >= 55) return 'Excellent';
    if (score >= 45) return 'Good';
    if (score >= 35) return 'Average';
    return 'Needs Improvement';
  }
}
