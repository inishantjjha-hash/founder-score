// lib/screens/dashboard/dashboard_screen.dart
// Analytics dashboard: streak, averages, line chart of recent scores.

import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:provider/provider.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:intl/intl.dart';

import '../../core/theme.dart';
import '../../core/constants.dart';
import '../../providers/review_provider.dart';
import '../../models/daily_review.dart';

class DashboardScreen extends StatelessWidget {
  const DashboardScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<ReviewProvider>();

    return Scaffold(
      backgroundColor: AppTheme.background,
      appBar: AppBar(title: const Text('Dashboard')),
      body: provider.loading
          ? const Center(
              child: CircularProgressIndicator(color: AppTheme.accent))
          : provider.reviews.isEmpty
              ? _buildEmptyState(context)
              : _buildContent(context, provider),
    );
  }

  Widget _buildEmptyState(BuildContext context) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Text('📊', style: TextStyle(fontSize: 64)),
          const SizedBox(height: 16),
          Text(
            'No data yet',
            style: Theme.of(context).textTheme.headlineMedium,
          ),
          const SizedBox(height: 8),
          Text(
            'Complete your first daily review\nto see your dashboard.',
            textAlign: TextAlign.center,
            style: Theme.of(context).textTheme.bodyMedium,
          ),
        ],
      ),
    );
  }

  Widget _buildContent(BuildContext context, ReviewProvider provider) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildKpiRow(context, provider),
          const SizedBox(height: 24),
          _buildChart(context, provider),
          const SizedBox(height: 24),
          _buildCategoryBreakdown(context, provider),
          const SizedBox(height: 40),
        ],
      ),
    );
  }

  // ── KPI Cards ─────────────────────────────────────────────────────────────

  Widget _buildKpiRow(BuildContext context, ReviewProvider provider) {
    final kpis = [
      _KpiData('🔥 Streak', '${provider.currentStreak}', 'days'),
      _KpiData('📅 7-Day', provider.weeklyAverage.toStringAsFixed(1), '/${AppConstants.maxScore}'),
      _KpiData('📆 30-Day', provider.monthlyAverage.toStringAsFixed(1), '/${AppConstants.maxScore}'),
      _KpiData('🏆 Best', '${provider.highestScore}', '/${AppConstants.maxScore}'),
    ];

    return GridView.builder(
      physics: const NeverScrollableScrollPhysics(),
      shrinkWrap: true,
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        crossAxisSpacing: 12,
        mainAxisSpacing: 12,
        childAspectRatio: 1.6,
      ),
      itemCount: kpis.length,
      itemBuilder: (ctx, i) => _KpiCard(data: kpis[i], delay: (i * 100).ms),
    );
  }

  // ── Score Chart ───────────────────────────────────────────────────────────

  Widget _buildChart(BuildContext context, ReviewProvider provider) {
    final data = provider.chartData(days: 30);
    if (data.isEmpty) return const SizedBox.shrink();

    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: AppTheme.surface,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: AppTheme.divider),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('Last 30 Days',
              style: Theme.of(context).textTheme.titleLarge),
          Text('Daily scores trend',
              style: Theme.of(context).textTheme.bodyMedium),
          const SizedBox(height: 24),
          SizedBox(
            height: 200,
            child: _ScoreLineChart(reviews: data),
          ),
        ],
      ),
    ).animate().fadeIn(delay: 300.ms);
  }

  // ── Category Breakdown ────────────────────────────────────────────────────

  Widget _buildCategoryBreakdown(BuildContext context, ReviewProvider provider) {
    if (provider.reviews.isEmpty) return const SizedBox.shrink();

    final categories = provider.categories;
    // Average score per category over all reviews
    final Map<String, double> avgScores = {};
    for (final cat in categories) {
      final vals = provider.reviews
          .map((r) => r.scores[cat.id] ?? 0)
          .where((v) => v > 0)
          .toList();
      avgScores[cat.id] = vals.isEmpty
          ? 0
          : vals.reduce((a, b) => a + b) / vals.length;
    }

    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: AppTheme.surface,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: AppTheme.divider),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('Category Averages',
              style: Theme.of(context).textTheme.titleLarge),
          Text('All-time averages per area',
              style: Theme.of(context).textTheme.bodyMedium),
          const SizedBox(height: 20),
          ...categories.asMap().entries.map((entry) {
            final i = entry.key;
            final cat = entry.value;
            final avg = avgScores[cat.id] ?? 0;
            final pct = avg / 10;
            final color = avg >= 8
                ? AppTheme.success
                : avg >= 6
                    ? AppTheme.accent
                    : avg >= 4
                        ? AppTheme.warning
                        : AppTheme.error;

            return Padding(
              padding: const EdgeInsets.only(bottom: 16),
              child: Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Row(
                        children: [
                          Text(cat.emoji,
                              style: const TextStyle(fontSize: 16)),
                          const SizedBox(width: 8),
                          Text(cat.label,
                              style: Theme.of(context).textTheme.titleMedium),
                        ],
                      ),
                      Text(
                        avg.toStringAsFixed(1),
                        style: TextStyle(
                          color: color,
                          fontWeight: FontWeight.w700,
                          fontSize: 16,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  ClipRRect(
                    borderRadius: BorderRadius.circular(4),
                    child: LinearProgressIndicator(
                      value: pct,
                      backgroundColor: AppTheme.divider,
                      valueColor: AlwaysStoppedAnimation(color),
                      minHeight: 6,
                    ),
                  ),
                ],
              ).animate().fadeIn(delay: ((i + 4) * 80).ms),
            );
          }),
        ],
      ),
    ).animate().fadeIn(delay: 400.ms);
  }
}

// ── Chart Widget ──────────────────────────────────────────────────────────────

class _ScoreLineChart extends StatelessWidget {
  final List<DailyReview> reviews;
  const _ScoreLineChart({required this.reviews});

  @override
  Widget build(BuildContext context) {
    final spots = reviews.asMap().entries.map((e) {
      return FlSpot(e.key.toDouble(), e.value.totalScore.toDouble());
    }).toList();

    return LineChart(
      LineChartData(
        backgroundColor: Colors.transparent,
        gridData: FlGridData(
          show: true,
          drawVerticalLine: false,
          horizontalInterval: 15,
          getDrawingHorizontalLine: (_) => FlLine(
            color: AppTheme.divider,
            strokeWidth: 1,
          ),
        ),
        borderData: FlBorderData(show: false),
        titlesData: FlTitlesData(
          leftTitles: AxisTitles(
            sideTitles: SideTitles(
              showTitles: true,
              interval: 15,
              reservedSize: 32,
              getTitlesWidget: (v, _) => Text(
                v.round().toString(),
                style: const TextStyle(
                    color: AppTheme.textSecondary, fontSize: 11),
              ),
            ),
          ),
          rightTitles:
              const AxisTitles(sideTitles: SideTitles(showTitles: false)),
          topTitles:
              const AxisTitles(sideTitles: SideTitles(showTitles: false)),
          bottomTitles: AxisTitles(
            sideTitles: SideTitles(
              showTitles: reviews.length <= 14,
              reservedSize: 28,
              getTitlesWidget: (v, _) {
                final i = v.round();
                if (i < 0 || i >= reviews.length) return const SizedBox();
                final d = reviews[i].date;
                return Text(
                  DateFormat('d/M').format(d),
                  style: const TextStyle(
                      color: AppTheme.textSecondary, fontSize: 10),
                );
              },
            ),
          ),
        ),
        minY: 0,
        maxY: 60,
        lineBarsData: [
          LineChartBarData(
            spots: spots,
            isCurved: true,
            curveSmoothness: 0.35,
            color: AppTheme.accent,
            barWidth: 2.5,
            dotData: FlDotData(
              show: reviews.length <= 14,
              getDotPainter: (spot, pct, bar, i) => FlDotCirclePainter(
                radius: 4,
                color: AppTheme.accent,
                strokeWidth: 2,
                strokeColor: AppTheme.background,
              ),
            ),
            belowBarData: BarAreaData(
              show: true,
              gradient: LinearGradient(
                colors: [
                  AppTheme.accent.withOpacity(0.25),
                  AppTheme.accent.withOpacity(0),
                ],
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
              ),
            ),
          ),
        ],
        lineTouchData: LineTouchData(
          touchTooltipData: LineTouchTooltipData(
            getTooltipColor: (_) => AppTheme.surfaceHigh,
            getTooltipItems: (spots) => spots.map((s) {
              final i = s.spotIndex;
              final r = reviews[i];
              return LineTooltipItem(
                '${r.totalScore}/${AppConstants.maxScore}\n${DateFormat('MMM d').format(r.date)}',
                const TextStyle(
                  color: AppTheme.accent,
                  fontWeight: FontWeight.w700,
                  fontSize: 13,
                ),
              );
            }).toList(),
          ),
        ),
      ),
    );
  }
}

// ── KPI Card ──────────────────────────────────────────────────────────────────

class _KpiData {
  final String label;
  final String value;
  final String suffix;
  _KpiData(this.label, this.value, this.suffix);
}

class _KpiCard extends StatelessWidget {
  final _KpiData data;
  final Duration delay;
  const _KpiCard({required this.data, required this.delay});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppTheme.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppTheme.divider),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            data.label,
            style: Theme.of(context)
                .textTheme
                .labelSmall
                ?.copyWith(color: AppTheme.textSecondary),
          ),
          RichText(
            text: TextSpan(
              children: [
                TextSpan(
                  text: data.value,
                  style:
                      Theme.of(context).textTheme.headlineLarge?.copyWith(
                            color: AppTheme.textPrimary,
                            fontWeight: FontWeight.w800,
                          ),
                ),
                TextSpan(
                  text: data.suffix,
                  style: Theme.of(context)
                      .textTheme
                      .bodyMedium
                      ?.copyWith(color: AppTheme.textSecondary),
                ),
              ],
            ),
          ),
        ],
      ),
    ).animate().fadeIn(delay: delay).scale(begin: const Offset(0.95, 0.95));
  }
}
