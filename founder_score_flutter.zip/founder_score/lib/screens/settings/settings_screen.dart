// lib/screens/settings/settings_screen.dart
// Settings: reminder time picker, category editor, CSV export.

import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:provider/provider.dart';

import '../../core/theme.dart';
import '../../core/constants.dart';
import '../../models/category.dart';
import '../../providers/settings_provider.dart';
import '../../providers/review_provider.dart';
import '../../services/export_service.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.background,
      appBar: AppBar(title: const Text('Settings')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _SectionLabel(label: 'NOTIFICATIONS'),
            const SizedBox(height: 8),
            _ReminderTile(),
            const SizedBox(height: 24),
            _SectionLabel(label: 'SCORING CATEGORIES'),
            const SizedBox(height: 8),
            _CategoriesEditor(),
            const SizedBox(height: 24),
            _SectionLabel(label: 'DATA'),
            const SizedBox(height: 8),
            _ExportTile(),
            const SizedBox(height: 40),
          ],
        ),
      ),
    );
  }
}

class _SectionLabel extends StatelessWidget {
  final String label;
  const _SectionLabel({required this.label});

  @override
  Widget build(BuildContext context) {
    return Text(
      label,
      style: Theme.of(context).textTheme.labelSmall?.copyWith(
            color: AppTheme.textSecondary,
            letterSpacing: 1.2,
          ),
    );
  }
}

// ── Reminder Tile ─────────────────────────────────────────────────────────────

class _ReminderTile extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final settings = context.watch<SettingsProvider>();

    return _SettingsTile(
      icon: '🔔',
      title: 'Daily Reminder',
      subtitle: settings.formattedTime,
      onTap: () => _pickTime(context, settings),
    );
  }

  Future<void> _pickTime(
      BuildContext context, SettingsProvider settings) async {
    final picked = await showTimePicker(
      context: context,
      initialTime: TimeOfDay(
        hour: settings.reminderHour,
        minute: settings.reminderMinute,
      ),
      builder: (ctx, child) => Theme(
        data: Theme.of(ctx).copyWith(
          colorScheme: const ColorScheme.dark(
            primary: AppTheme.accent,
            surface: AppTheme.surface,
          ),
        ),
        child: child!,
      ),
    );

    if (picked != null) {
      await settings.setReminderTime(picked.hour, picked.minute);
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
                'Reminder set for ${settings.formattedTime}',
                style: const TextStyle(color: AppTheme.textPrimary)),
            backgroundColor: AppTheme.surface,
          ),
        );
      }
    }
  }
}

// ── Categories Editor ─────────────────────────────────────────────────────────

class _CategoriesEditor extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final provider = context.watch<ReviewProvider>();
    final categories = provider.categories;

    return Container(
      decoration: BoxDecoration(
        color: AppTheme.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppTheme.divider),
      ),
      child: Column(
        children: [
          ...categories.asMap().entries.map((entry) {
            final i = entry.key;
            final cat = entry.value;
            return _CategoryRow(
              category: cat,
              isLast: i == categories.length - 1,
              onEdit: () => _showEditDialog(context, provider, cat),
            );
          }),
          // Reset to defaults button
          Padding(
            padding: const EdgeInsets.all(12),
            child: TextButton(
              onPressed: () => _resetCategories(context, provider),
              child: const Text('Reset to defaults'),
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _showEditDialog(
      BuildContext context, ReviewProvider provider, ScoringCategory cat) async {
    final labelCtrl = TextEditingController(text: cat.label);
    final emojiCtrl = TextEditingController(text: cat.emoji);

    await showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: AppTheme.surface,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: Text('Edit Category',
            style: Theme.of(ctx).textTheme.titleLarge),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: emojiCtrl,
              decoration: const InputDecoration(labelText: 'Emoji'),
              style: const TextStyle(color: AppTheme.textPrimary, fontSize: 24),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: labelCtrl,
              decoration: const InputDecoration(labelText: 'Label'),
              style:
                  const TextStyle(color: AppTheme.textPrimary, fontSize: 16),
            ),
          ],
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx),
              child: const Text('Cancel')),
          ElevatedButton(
            onPressed: () async {
              final newCats = provider.categories.map((c) {
                if (c.id == cat.id) {
                  return c.copyWith(
                    label: labelCtrl.text.trim(),
                    emoji: emojiCtrl.text.trim(),
                  );
                }
                return c;
              }).toList();
              await provider.saveCategories(newCats);
              if (ctx.mounted) Navigator.pop(ctx);
            },
            child: const Text('Save'),
          ),
        ],
      ),
    );
  }

  Future<void> _resetCategories(
      BuildContext context, ReviewProvider provider) async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: AppTheme.surface,
        title: Text('Reset categories?',
            style: Theme.of(ctx).textTheme.titleLarge),
        content: const Text(
            'This will restore the 6 default categories.',
            style: TextStyle(color: AppTheme.textSecondary)),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('Cancel')),
          ElevatedButton(
              onPressed: () => Navigator.pop(ctx, true),
              child: const Text('Reset')),
        ],
      ),
    );
    if (confirm == true) {
      final defaults = kDefaultCategories.map(ScoringCategory.fromMap).toList();
      await provider.saveCategories(defaults);
    }
  }
}

class _CategoryRow extends StatelessWidget {
  final ScoringCategory category;
  final bool isLast;
  final VoidCallback onEdit;

  const _CategoryRow({
    required this.category,
    required this.isLast,
    required this.onEdit,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        ListTile(
          leading: Text(category.emoji,
              style: const TextStyle(fontSize: 22)),
          title: Text(category.label,
              style: Theme.of(context).textTheme.titleMedium),
          trailing: IconButton(
            icon: const Icon(Icons.edit_outlined,
                color: AppTheme.textSecondary, size: 20),
            onPressed: onEdit,
          ),
        ),
        if (!isLast)
          const Divider(
              height: 1, indent: 56, endIndent: 16, color: AppTheme.divider),
      ],
    );
  }
}

// ── Export Tile ───────────────────────────────────────────────────────────────

class _ExportTile extends StatelessWidget {
  final ExportService _export = ExportService();

  @override
  Widget build(BuildContext context) {
    return _SettingsTile(
      icon: '📤',
      title: 'Export to CSV',
      subtitle: 'Share all your review data',
      onTap: () async {
        try {
          await _export.exportToCsv();
        } catch (e) {
          if (context.mounted) {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                content: Text('Export failed: $e',
                    style: const TextStyle(color: AppTheme.textPrimary)),
                backgroundColor: AppTheme.error,
              ),
            );
          }
        }
      },
    );
  }
}

// ── Shared Settings Tile ──────────────────────────────────────────────────────

class _SettingsTile extends StatelessWidget {
  final String icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;

  const _SettingsTile({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Material(
      color: AppTheme.surface,
      borderRadius: BorderRadius.circular(16),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(16),
        child: Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: AppTheme.divider),
          ),
          child: Row(
            children: [
              Container(
                width: 44,
                height: 44,
                decoration: BoxDecoration(
                  color: AppTheme.surfaceHigh,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Center(
                  child: Text(icon,
                      style: const TextStyle(fontSize: 22)),
                ),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(title,
                        style: Theme.of(context).textTheme.titleMedium),
                    const SizedBox(height: 2),
                    Text(subtitle,
                        style: Theme.of(context).textTheme.bodyMedium),
                  ],
                ),
              ),
              const Icon(Icons.chevron_right_rounded,
                  color: AppTheme.textSecondary),
            ],
          ),
        ),
      ),
    );
  }
}
