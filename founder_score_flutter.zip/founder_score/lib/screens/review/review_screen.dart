// lib/screens/review/review_screen.dart
// The main daily review entry screen with sliders and text fields.

import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:provider/provider.dart';
import 'package:intl/intl.dart';

import '../../core/theme.dart';
import '../../core/constants.dart';
import '../../models/daily_review.dart';
import '../../models/category.dart';
import '../../providers/review_provider.dart';

class ReviewScreen extends StatefulWidget {
  const ReviewScreen({super.key});

  @override
  State<ReviewScreen> createState() => _ReviewScreenState();
}

class _ReviewScreenState extends State<ReviewScreen> {
  final Map<String, double> _scores = {};
  final _winController = TextEditingController();
  final _mistakeController = TextEditingController();
  final _builtController = TextEditingController();
  final _tomorrowController = TextEditingController();
  bool _saving = false;
  bool _loaded = false;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (!_loaded) {
      _loaded = true;
      final provider = context.read<ReviewProvider>();
      final today = provider.todayReview;
      final categories = provider.categories;

      // Pre-fill scores (defaults or existing)
      for (final cat in categories) {
        _scores[cat.id] = today?.scores[cat.id] ?? 5.0;
      }
      if (today != null) {
        _winController.text = today.biggestWin;
        _mistakeController.text = today.biggestMistake;
        _builtController.text = today.whatIBuilt;
        _tomorrowController.text = today.tomorrowPriority;
      }
    }
  }

  @override
  void dispose() {
    _winController.dispose();
    _mistakeController.dispose();
    _builtController.dispose();
    _tomorrowController.dispose();
    super.dispose();
  }

  int get _totalScore => _scores.values.fold(0, (s, v) => s + v.round());

  Future<void> _save() async {
    setState(() => _saving = true);
    final provider = context.read<ReviewProvider>();
    final today = DateTime.now();
    final id = DateFormat('yyyy-MM-dd').format(today);

    final review = DailyReview(
      id: id,
      date: today,
      scores: Map.from(_scores),
      biggestWin: _winController.text.trim(),
      biggestMistake: _mistakeController.text.trim(),
      whatIBuilt: _builtController.text.trim(),
      tomorrowPriority: _tomorrowController.text.trim(),
    );

    await provider.saveReview(review);
    if (mounted) {
      setState(() => _saving = false);
      _showSuccessSheet();
    }
  }

  void _showSuccessSheet() {
    final score = _totalScore;
    final color = AppTheme.scoreColor(score);
    final label = AppTheme.scoreLabel(score);

    showModalBottomSheet(
      context: context,
      backgroundColor: AppTheme.surface,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (ctx) => Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 40,
              height: 4,
              decoration: BoxDecoration(
                color: AppTheme.divider,
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            const SizedBox(height: 24),
            const Text('✅', style: TextStyle(fontSize: 48)),
            const SizedBox(height: 16),
            Text(
              '$score / ${AppConstants.maxScore}',
              style: Theme.of(context).textTheme.displayMedium?.copyWith(
                    color: color,
                  ),
            ),
            const SizedBox(height: 8),
            Container(
              padding:
                  const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
              decoration: BoxDecoration(
                color: color.withOpacity(0.15),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Text(
                label,
                style: TextStyle(
                    color: color,
                    fontWeight: FontWeight.w700,
                    fontSize: 14),
              ),
            ),
            const SizedBox(height: 24),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: () {
                  Navigator.pop(ctx);
                  Navigator.pop(context);
                },
                child: const Text('Done'),
              ),
            ),
            const SizedBox(height: 8),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final categories = context.watch<ReviewProvider>().categories;

    return Scaffold(
      backgroundColor: AppTheme.background,
      appBar: AppBar(
        title: const Text('Daily Review'),
        actions: [
          // Live score indicator in top bar
          Container(
            margin: const EdgeInsets.only(right: 16),
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
            decoration: BoxDecoration(
              color: AppTheme.accentDim,
              borderRadius: BorderRadius.circular(20),
            ),
            child: Text(
              '$_totalScore/${AppConstants.maxScore}',
              style: const TextStyle(
                color: AppTheme.accent,
                fontWeight: FontWeight.w700,
                fontSize: 14,
              ),
            ),
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.symmetric(horizontal: 20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(height: 8),
            _SectionHeader(
              title: 'Score Your Day',
              subtitle: 'Rate each area from 0 to 10',
            ),
            const SizedBox(height: 16),
            // Score sliders
            ...categories.asMap().entries.map((entry) {
              final i = entry.key;
              final cat = entry.value;
              return _ScoreSlider(
                category: cat,
                value: _scores[cat.id] ?? 5,
                onChanged: (v) => setState(() => _scores[cat.id] = v),
                animDelay: (i * 80).ms,
              );
            }),
            const SizedBox(height: 32),
            // Divider
            Container(height: 1, color: AppTheme.divider),
            const SizedBox(height: 24),
            _SectionHeader(
              title: 'Reflection',
              subtitle: 'Be honest. This is for you.',
            ),
            const SizedBox(height: 16),
            _ReflectionField(
              controller: _winController,
              label: 'Biggest win today',
              hint: 'What went really well?',
              emoji: '🏆',
            ),
            const SizedBox(height: 12),
            _ReflectionField(
              controller: _mistakeController,
              label: 'Biggest mistake today',
              hint: 'What would you do differently?',
              emoji: '⚡',
            ),
            const SizedBox(height: 12),
            _ReflectionField(
              controller: _builtController,
              label: 'What did I build today?',
              hint: 'Be specific. Code, content, relationships...',
              emoji: '🔨',
            ),
            const SizedBox(height: 12),
            _ReflectionField(
              controller: _tomorrowController,
              label: 'Top priority for tomorrow',
              hint: 'The one thing that moves the needle.',
              emoji: '🎯',
            ),
            const SizedBox(height: 40),
            // Save button with total score
            _buildSaveButton(),
            const SizedBox(height: 40),
          ],
        ),
      ),
    );
  }

  Widget _buildSaveButton() {
    final score = _totalScore;
    final color = AppTheme.scoreColor(score);

    return Column(
      children: [
        // Score preview card
        Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            color: AppTheme.surface,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: AppTheme.divider),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    "Today's Score",
                    style: Theme.of(context).textTheme.bodyMedium,
                  ),
                  const SizedBox(height: 4),
                  Text(
                    AppTheme.scoreLabel(score),
                    style: TextStyle(
                        color: color,
                        fontWeight: FontWeight.w700,
                        fontSize: 14),
                  ),
                ],
              ),
              Text(
                '$score/${AppConstants.maxScore}',
                style: Theme.of(context).textTheme.displayMedium?.copyWith(
                      color: color,
                      fontWeight: FontWeight.w800,
                    ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 16),
        SizedBox(
          width: double.infinity,
          child: ElevatedButton(
            onPressed: _saving ? null : _save,
            child: _saving
                ? const SizedBox(
                    width: 20,
                    height: 20,
                    child: CircularProgressIndicator(
                        strokeWidth: 2, color: AppTheme.background))
                : const Text('Save Review'),
          ),
        ),
      ],
    );
  }
}

// ── Subwidgets ────────────────────────────────────────────────────────────────

class _SectionHeader extends StatelessWidget {
  final String title;
  final String subtitle;
  const _SectionHeader({required this.title, required this.subtitle});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(title, style: Theme.of(context).textTheme.headlineMedium),
        const SizedBox(height: 4),
        Text(subtitle, style: Theme.of(context).textTheme.bodyMedium),
      ],
    );
  }
}

class _ScoreSlider extends StatelessWidget {
  final ScoringCategory category;
  final double value;
  final ValueChanged<double> onChanged;
  final Duration animDelay;

  const _ScoreSlider({
    required this.category,
    required this.value,
    required this.onChanged,
    this.animDelay = Duration.zero,
  });

  Color _valueColor(double v) {
    if (v >= 8) return AppTheme.success;
    if (v >= 6) return AppTheme.accent;
    if (v >= 4) return AppTheme.warning;
    return AppTheme.error;
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
      decoration: BoxDecoration(
        color: AppTheme.surface,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: AppTheme.divider),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: [
                  Text(category.emoji,
                      style: const TextStyle(fontSize: 18)),
                  const SizedBox(width: 10),
                  Text(category.label,
                      style: Theme.of(context).textTheme.titleMedium),
                ],
              ),
              Container(
                width: 40,
                height: 40,
                decoration: BoxDecoration(
                  color: _valueColor(value).withOpacity(0.15),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Center(
                  child: Text(
                    value.round().toString(),
                    style: TextStyle(
                      color: _valueColor(value),
                      fontWeight: FontWeight.w800,
                      fontSize: 18,
                    ),
                  ),
                ),
              ),
            ],
          ),
          SliderTheme(
            data: Theme.of(context).sliderTheme.copyWith(
                  activeTrackColor: _valueColor(value),
                  thumbColor: _valueColor(value),
                  overlayColor: _valueColor(value).withOpacity(0.15),
                ),
            child: Slider(
              min: 0,
              max: 10,
              divisions: 10,
              value: value,
              label: value.round().toString(),
              onChanged: onChanged,
            ),
          ),
          // Min/max labels
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 4),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text('0',
                    style: Theme.of(context)
                        .textTheme
                        .labelSmall
                        ?.copyWith(color: AppTheme.textSecondary)),
                Text('10',
                    style: Theme.of(context)
                        .textTheme
                        .labelSmall
                        ?.copyWith(color: AppTheme.textSecondary)),
              ],
            ),
          ),
        ],
      ),
    ).animate().fadeIn(delay: animDelay).slideY(begin: 0.05);
  }
}

class _ReflectionField extends StatelessWidget {
  final TextEditingController controller;
  final String label;
  final String hint;
  final String emoji;

  const _ReflectionField({
    required this.controller,
    required this.label,
    required this.hint,
    required this.emoji,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Text(emoji, style: const TextStyle(fontSize: 16)),
            const SizedBox(width: 8),
            Text(label, style: Theme.of(context).textTheme.titleMedium),
          ],
        ),
        const SizedBox(height: 8),
        TextFormField(
          controller: controller,
          maxLines: 3,
          style: Theme.of(context)
              .textTheme
              .bodyLarge
              ?.copyWith(color: AppTheme.textPrimary),
          decoration: InputDecoration(hintText: hint),
        ),
      ],
    );
  }
}
