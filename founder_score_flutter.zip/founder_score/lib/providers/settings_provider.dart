// lib/providers/settings_provider.dart
// Manages reminder time setting.

import 'package:flutter/foundation.dart';
import '../core/constants.dart';
import '../services/storage_service.dart';
import '../services/notification_service.dart';

class SettingsProvider extends ChangeNotifier {
  final StorageService _storage = StorageService();
  final NotificationService _notifications = NotificationService();

  int _reminderHour = AppConstants.defaultReminderHour;
  int _reminderMinute = AppConstants.defaultReminderMinute;

  int get reminderHour => _reminderHour;
  int get reminderMinute => _reminderMinute;

  Future<void> load() async {
    _reminderHour = await _storage.getReminderHour();
    _reminderMinute = await _storage.getReminderMinute();
    notifyListeners();
  }

  Future<void> setReminderTime(int hour, int minute) async {
    _reminderHour = hour;
    _reminderMinute = minute;
    await _storage.setReminderTime(hour, minute);
    await _notifications.scheduleDailyReminder(hour: hour, minute: minute);
    notifyListeners();
  }

  String get formattedTime {
    final h = _reminderHour > 12
        ? _reminderHour - 12
        : (_reminderHour == 0 ? 12 : _reminderHour);
    final m = _reminderMinute.toString().padLeft(2, '0');
    final period = _reminderHour >= 12 ? 'PM' : 'AM';
    return '$h:$m $period';
  }
}
