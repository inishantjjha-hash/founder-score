// lib/providers/review_provider.dart
// Manages all review data and dashboard stats. Consumed via Provider.

import 'package:flutter/foundation.dart';
import 'package:intl/intl.dart';

import '../models/daily_review.dart';
import '../models/category.dart';
import '../services/storage_service.dart';

class ReviewProvider extends ChangeNotifier {
  final StorageService _storage = StorageService();

  List<DailyReview> _reviews = [];
  List<ScoringCategory> _categories = [];
  bool _loading = true;

  List<DailyReview> get reviews => _reviews;
  List<ScoringCategory> get categories => _categories;
  bool get loading => _loading;

  // ── Init ──────────────────────────────────────────────────────────────────

  Future<void> load() async {
    _loading = true;
    notifyListeners();

    _reviews = await _storage.getAllReviews();
    _categories = await _storage.getCategories();

    _loading = false;
    notifyListeners();
  }

  // ── Today's review ────────────────────────────────────────────────────────

  String get todayId => DateFormat('yyyy-MM-dd').format(DateTime.now());

  DailyReview? get todayReview {
    try {
      return _reviews.firstWhere((r) => r.id == todayId);
    } catch (_) {
      return null;
    }
  }

  bool get hasReviewedToday => todayReview != null;

  /// Save (or update) today's review.
  Future<void> saveReview(DailyReview review) async {
    await _storage.saveReview(review);
    // Update local cache
    final idx = _reviews.indexWhere((r) => r.id == review.id);
    if (idx >= 0) {
      _reviews[idx] = review;
    } else {
      _reviews.insert(0, review);
    }
    notifyListeners();
  }

  // ── Dashboard stats ───────────────────────────────────────────────────────

  /// Current streak: consecutive days ending today (or yesterday).
  int get currentStreak {
    if (_reviews.isEmpty) return 0;

    final sorted = List<DailyReview>.from(_reviews)
      ..sort((a, b) => b.date.compareTo(a.date));

    int streak = 0;
    DateTime cursor = DateTime.now();

    // If today isn't reviewed yet, start from yesterday
    if (!hasReviewedToday) {
      cursor = cursor.subtract(const Duration(days: 1));
    }

    for (final review in sorted) {
      final diff = _dayDiff(cursor, review.date);
      if (diff == 0) {
        streak++;
        cursor = cursor.subtract(const Duration(days: 1));
      } else if (diff > 0) {
        break; // Gap found
      }
    }
    return streak;
  }

  int _dayDiff(DateTime a, DateTime b) {
    final da = DateTime(a.year, a.month, a.day);
    final db = DateTime(b.year, b.month, b.day);
    return da.difference(db).inDays;
  }

  /// Weekly average score (last 7 days that have entries).
  double get weeklyAverage {
    final week = _reviews.where((r) {
      return r.date.isAfter(DateTime.now().subtract(const Duration(days: 7)));
    }).toList();
    if (week.isEmpty) return 0;
    return week.map((r) => r.totalScore).reduce((a, b) => a + b) / week.length;
  }

  /// Monthly average (last 30 days with entries).
  double get monthlyAverage {
    final month = _reviews.where((r) {
      return r.date.isAfter(DateTime.now().subtract(const Duration(days: 30)));
    }).toList();
    if (month.isEmpty) return 0;
    return month.map((r) => r.totalScore).reduce((a, b) => a + b) /
        month.length;
  }

  int get highestScore =>
      _reviews.isEmpty ? 0 : _reviews.map((r) => r.totalScore).reduce((a, b) => a > b ? a : b);

  int get lowestScore =>
      _reviews.isEmpty ? 0 : _reviews.map((r) => r.totalScore).reduce((a, b) => a < b ? a : b);

  /// Returns last N reviews sorted oldest→newest (for chart).
  List<DailyReview> chartData({int days = 30}) {
    final cutoff = DateTime.now().subtract(Duration(days: days));
    return _reviews
        .where((r) => r.date.isAfter(cutoff))
        .toList()
      ..sort((a, b) => a.date.compareTo(b.date));
  }

  // ── Categories ────────────────────────────────────────────────────────────

  Future<void> saveCategories(List<ScoringCategory> cats) async {
    await _storage.saveCategories(cats);
    _categories = cats;
    notifyListeners();
  }
}
