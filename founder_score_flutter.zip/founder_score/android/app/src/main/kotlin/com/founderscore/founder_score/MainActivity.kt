// android/app/src/main/kotlin/com/founderscore/founder_score/MainActivity.kt
package com.founderscore.founder_score

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
