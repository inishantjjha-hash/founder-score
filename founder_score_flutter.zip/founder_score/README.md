# Founder Score — Android App

A personal accountability tracker for entrepreneurs. Score your day, track your streak, build the habit of daily reflection.

---

## Project Structure

```
founder_score/
├── lib/
│   ├── main.dart                    ← Entry point
│   ├── app.dart                     ← MaterialApp + navigation shell
│   ├── core/
│   │   ├── theme.dart               ← Design system (colors, typography)
│   │   └── constants.dart           ← App-wide constants
│   ├── models/
│   │   ├── daily_review.dart        ← Review data model + SQLite serialisation
│   │   └── category.dart            ← Scoring category model
│   ├── services/
│   │   ├── storage_service.dart     ← SQLite + SharedPreferences wrapper
│   │   ├── notification_service.dart← Daily exact-time notifications
│   │   └── export_service.dart      ← CSV export via share sheet
│   ├── providers/
│   │   ├── review_provider.dart     ← Reviews state + dashboard stats
│   │   └── settings_provider.dart   ← Reminder time state
│   └── screens/
│       ├── home/home_screen.dart    ← Today's status + quick-start card
│       ├── review/review_screen.dart← Sliders + reflection fields
│       ├── dashboard/dashboard_screen.dart ← Charts + KPI cards
│       └── settings/settings_screen.dart  ← Reminder, categories, export
├── android/
│   ├── app/
│   │   ├── build.gradle             ← App-level Gradle config
│   │   └── src/main/
│   │       ├── AndroidManifest.xml  ← Permissions + receivers
│   │       └── kotlin/...MainActivity.kt
│   ├── build.gradle                 ← Project-level Gradle
│   ├── settings.gradle
│   └── gradle.properties
└── pubspec.yaml                     ← Flutter dependencies
```

---

## Prerequisites

| Tool | Version |
|------|---------|
| Flutter SDK | ≥ 3.19 (stable channel) |
| Dart | ≥ 3.0 |
| Android Studio / VS Code | Latest |
| Android SDK | API 34 |
| Java | 17 (via Android Studio) |

---

## Setup & Run

```bash
# 1. Get dependencies
flutter pub get

# 2. Connect device or start emulator (API 21+)
flutter devices

# 3. Run in debug mode
flutter run

# 4. If you hit Gradle issues, clean first
flutter clean && flutter pub get
```

---

## Build a Release APK

```bash
# 1. Clean
flutter clean

# 2. Get deps
flutter pub get

# 3. Build release APK (unsigned, fine for sideloading)
flutter build apk --release

# Output: build/app/outputs/flutter-apk/app-release.apk
```

### Install directly on device
```bash
flutter install   # installs debug build on connected device
# or
adb install build/app/outputs/flutter-apk/app-release.apk
```

### Build a split APK (smaller file sizes per architecture)
```bash
flutter build apk --split-per-abi --release
# Produces:
#   app-armeabi-v7a-release.apk  (~15MB) — older devices
#   app-arm64-v8a-release.apk    (~17MB) — modern devices
#   app-x86_64-release.apk       (~17MB) — emulators
```

### Build an App Bundle (for Play Store)
```bash
flutter build appbundle --release
# Output: build/app/outputs/bundle/release/app-release.aab
```

---

## Testing Each Feature

### 1. Daily Review
- Open app → tap "Start Daily Review"
- Adjust each slider (0–10)
- Fill in the 4 reflection fields
- Tap "Save Review"
- **Expected:** Score sheet appears, then returns to Home showing "Today's Score"

### 2. Scoring Logic
- Set all sliders to 10 → score = 60/60 → "Excellent"
- Set all sliders to 5 → score = 30/60 → "Needs Improvement"

### 3. Notifications
- Go to Settings → tap Daily Reminder → set to 1–2 minutes from now
- Wait → notification should appear
- If no notification: check Android Settings → Apps → Founder Score → Notifications = ON

### 4. Dashboard
- Complete 3+ reviews (you can back-date by changing device clock)
- Switch to Dashboard tab
- Verify: streak counter, weekly/monthly averages, line chart, category bars

### 5. CSV Export
- Settings → Export to CSV
- Share sheet appears → choose Files/Drive to save
- Open CSV — verify columns: Date, Study, Business, ... Total Score, reflections

### 6. Category Editing
- Settings → tap ✏️ on any category
- Change label/emoji → Save
- Go to Review screen → verify updated category appears

### 7. Persistence
- Enter a review, close the app completely (swipe away)
- Reopen → today's score still shows on Home

---

## Notifications on Android 12+

Android 12+ requires the `SCHEDULE_EXACT_ALARM` permission.
The app requests this automatically via `flutter_local_notifications`.

If exact alarms aren't firing:
1. Settings → Apps → Founder Score → Alarms & Reminders → ON
2. Settings → Battery → Founder Score → Unrestricted

---

## Troubleshooting

| Issue | Fix |
|-------|-----|
| `Gradle build failed` | Run `flutter clean && flutter pub get`, then check Java 17 is active |
| `Notification not showing` | Grant notification permission in Android Settings |
| `MissingPluginException` | Run `flutter pub get` and restart the app |
| `Charts not rendering` | Ensure `fl_chart: ^0.69.0` is in pubspec and deps are fetched |
| `Unable to open database` | Check device storage isn't full |

---

## Dependencies

| Package | Purpose |
|---------|---------|
| `provider` | State management |
| `sqflite` | SQLite local database |
| `shared_preferences` | Settings persistence |
| `flutter_local_notifications` | Daily push notifications |
| `timezone` | Accurate timezone-aware scheduling |
| `fl_chart` | Line chart on dashboard |
| `csv` | CSV serialisation |
| `share_plus` | Native share sheet |
| `path_provider` | Temp directory for CSV file |
| `google_fonts` | Space Grotesk + IBM Plex Sans |
| `flutter_animate` | Smooth entry animations |
| `intl` | Date formatting |
